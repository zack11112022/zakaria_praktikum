package com.example.zakaria_3tia.Home.pertemuan_6

import android.os.Bundle
import android.view.MenuItem
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.fragment.app.Fragment
import com.example.zakaria_3tia.R
import com.example.zakaria_3tia.databinding.ActivityEnamBinding

class EnamActivity : AppCompatActivity() {

    private lateinit var binding: ActivityEnamBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        binding = ActivityEnamBinding.inflate(layoutInflater)
        setContentView(binding.root)

        ViewCompat.setOnApplyWindowInsetsListener(binding.main) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        setSupportActionBar(binding.toolbar)
        supportActionBar?.apply {
            title = "HALAMAN PERTEMUAN 6"
            subtitle = "Fragment Zakaria"
            setDisplayHomeAsUpEnabled(true)
            setDisplayShowHomeEnabled(true)
            setHomeAsUpIndicator(R.drawable.ic_arrow_back)

        }

        setSupportActionBar(binding.toolbar)

        if (savedInstanceState == null) {
            replaceFragment(SatuFragment())
        }

        binding.btnFrag1.setOnClickListener {
            replaceFragment(SatuFragment())
        }

        binding.btnFrag2.setOnClickListener {
            replaceFragment(DuaFragment())
        }

        binding.btnFrag3.setOnClickListener {
            replaceFragment(TigaFragment())
        }
    }
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            android.R.id.home -> {
                onBackPressedDispatcher.onBackPressed()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun replaceFragment(fragment: Fragment) {
        supportFragmentManager.beginTransaction()
            .replace(R.id.containerFragment, fragment)
            .commit()
    }
}
